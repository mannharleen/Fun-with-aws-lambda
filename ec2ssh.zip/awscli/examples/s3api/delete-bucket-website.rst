The following command deletes a website configuration from a bucket named ``my-bucket``::

  aws s3api delete-bucket-website --bucket my-bucket
