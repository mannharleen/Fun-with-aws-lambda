**To leave an organization**

The following example shows how to remove your member account from an organization.  

Command::

  aws organizations leave-organization